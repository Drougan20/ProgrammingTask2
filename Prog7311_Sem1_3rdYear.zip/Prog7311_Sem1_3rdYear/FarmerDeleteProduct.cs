﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;



namespace Prog7311_Sem1_3rdYear
{
    public partial class FarmerDeleteProduct : Form
    {
        SqlConnection sc = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\MohammadDb.mdf;Integrated Security=True");
        SqlCommand scm = new SqlCommand();

        public FarmerDeleteProduct()
        {
            InitializeComponent();
        }

        private void DeleteProdBtn_Click(object sender, EventArgs e)
        {
            sc.Open();
            var prodid = FarmerProdIdDelete.Text;
            string deloption;
            deloption = "Select FROM FarmerDeleteProduct WHERE ProductID = @prodid";
            scm = new SqlCommand(deloption, sc);
            scm.Connection = sc;
            scm.CommandType = CommandType.Text;
            scm.Parameters.AddWithValue("@prodid",prodid);
            SqlDataReader sdr = scm.ExecuteReader();

            if(sdr.HasRows)
            {
                scm = new SqlCommand("Delete FROM FarmerDeleteProduct WHERE ProductID = @prodid");
                scm.Connection = sc;
                scm.CommandType = CommandType.Text;
            }
        }
    }
}
