﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Prog7311_Sem1_3rdYear
{
    public partial class LoginPage : Form

    {
        SqlConnection strcon = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\JALAAL\\source\\repos\\Prog7311_Sem1_3rdYear\\bin\\Debug\\MohammmadDb.mdf;Integrated Security=True");


        public LoginPage()
        {
            InitializeComponent();
        }

        private void FCLoginPageBtn_Click(object sender, EventArgs e)
        {
            var un1 = FCUNLoginPageTb.Text.Trim();
            var pw1 = FCPWLoginPageTb.Text.Trim();
            int farmerauth = un1.IndexOf(".Farmer");
            int empauth = un1.IndexOf(".Employee");

            strcon.Open();
            SqlCommand farmercomm = new SqlCommand("Select FarmerUsername,FarmerPassword FROM FarmerRegTabel WHERE FarmerUsername=@un1 AND FarmerPassword = @pw1",strcon);
            SqlCommand empcomm = new SqlCommand("Select empusername,emppassword FROM EmployeeRegTable WHERE empusername=@un1 AND emppassword = @pw1",strcon);
            SqlCommand usercomm = new SqlCommand("Select Username,UserPassword FROM UserRegTable WHERE Username=@un1 AND UserPassword = @pw1",strcon);

            

            if (farmerauth>0)
            {
                
                farmercomm.Connection = strcon;
                farmercomm.CommandType = CommandType.Text;
                farmercomm.Parameters.AddWithValue("@un1", un1);
                farmercomm.Parameters.AddWithValue("@pw1", pw1);
                SqlDataReader Fr = farmercomm.ExecuteReader();


                if (Fr.HasRows)
                {
                    Farmer f1 = new Farmer();
                    f1.Show();

                }

                else
                {
                    MessageBox.Show("Username or Password in invalid");
                }

                strcon.Close();
            }


            if (empauth > 0)
            {
                empcomm.Connection = strcon;
                empcomm.CommandType = CommandType.Text;
                empcomm.Parameters.AddWithValue("@un1", un1);
                empcomm.Parameters.AddWithValue("@pw1", pw1);
                SqlDataReader Er = empcomm.ExecuteReader();


                if (Er.HasRows)
                {
                    Employee e1 = new Employee();
                    e1.Show();

                }

                else
                {
                    MessageBox.Show("Username or Password in invalid");
                }
                strcon.Close();
            }

            if(farmerauth==0 && empauth == 0)
            {
                
                usercomm.Connection = strcon;
                usercomm.CommandType = CommandType.Text;
                usercomm.Parameters.AddWithValue("@un1", un1);
                usercomm.Parameters.AddWithValue("@pw1", pw1);
                SqlDataReader Ur = usercomm.ExecuteReader();


                if (Ur.HasRows)
                {
                    FarmCentralHomePage fhp1 = new FarmCentralHomePage();
                    fhp1.Show();

                }

                else
                {
                    MessageBox.Show("Username or Password in invalid");
                }
                strcon.Close();
            }



        }
    }
}
