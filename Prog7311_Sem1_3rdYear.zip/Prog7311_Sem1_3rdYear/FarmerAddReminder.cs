﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Prog7311_Sem1_3rdYear
{
    public partial class FarmerAddReminder : Form
    {
        SqlConnection FARscn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\MohammadDb.mdf;Integrated Security=True");
        SqlCommand FARscm = new SqlCommand();

        public FarmerAddReminder()
        {
            InitializeComponent();
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

        }

        private void addrembtn_Click(object sender, EventArgs e)
        {
            FARscn.Open();
            string addrem;
            RemTime.Format = DateTimePickerFormat.Custom;
            string time = RemTime.Value.ToString();
            AddReminderDGV.Rows.Add(FarmerRemNameTb.Text.Trim(),FarmerRemDescTb.Text.Trim(), time);
            addrem = "Insert into FarmerReminderTable(ReminderName,ReminderDesc,ReminderDate)values('" +
            FarmerRemNameTb.Text.Trim().ToString() + "','" + FarmerRemDescTb.Text.Trim().ToString() + "','" + time + "')";
            FARscm = new SqlCommand(addrem, FARscn);
            FARscm.ExecuteNonQuery();
            MessageBox.Show("Your Reminder Has Been Added");

        }
    }
}
