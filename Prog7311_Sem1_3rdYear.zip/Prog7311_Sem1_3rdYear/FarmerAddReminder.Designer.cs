﻿
namespace Prog7311_Sem1_3rdYear
{
    partial class FarmerAddReminder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.FarmerRemDescTb = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.addrembtn = new System.Windows.Forms.Button();
            this.RemTime = new System.Windows.Forms.DateTimePicker();
            this.AddReminderDGV = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.FarmerRemNameTb = new System.Windows.Forms.TextBox();
            this.farmerremname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.farmerremdesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.farmerremdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.AddReminderDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(81, 123);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Reminder Description:";
            // 
            // FarmerRemDescTb
            // 
            this.FarmerRemDescTb.Location = new System.Drawing.Point(198, 123);
            this.FarmerRemDescTb.Name = "FarmerRemDescTb";
            this.FarmerRemDescTb.Size = new System.Drawing.Size(425, 20);
            this.FarmerRemDescTb.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(294, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Add A Reminder";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(81, 200);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Reminder Date:";
            // 
            // addrembtn
            // 
            this.addrembtn.BackColor = System.Drawing.Color.White;
            this.addrembtn.Location = new System.Drawing.Point(329, 353);
            this.addrembtn.Name = "addrembtn";
            this.addrembtn.Size = new System.Drawing.Size(142, 23);
            this.addrembtn.TabIndex = 6;
            this.addrembtn.Text = "Add";
            this.addrembtn.UseVisualStyleBackColor = false;
            this.addrembtn.Click += new System.EventHandler(this.addrembtn_Click);
            // 
            // RemTime
            // 
            this.RemTime.CustomFormat = "yyyy/MM/dd      HH:mm:ss";
            this.RemTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.RemTime.Location = new System.Drawing.Point(168, 200);
            this.RemTime.Name = "RemTime";
            this.RemTime.Size = new System.Drawing.Size(160, 20);
            this.RemTime.TabIndex = 7;
            // 
            // AddReminderDGV
            // 
            this.AddReminderDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.AddReminderDGV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.farmerremname,
            this.farmerremdesc,
            this.farmerremdate});
            this.AddReminderDGV.Location = new System.Drawing.Point(12, 406);
            this.AddReminderDGV.Name = "AddReminderDGV";
            this.AddReminderDGV.RowHeadersWidth = 30;
            this.AddReminderDGV.Size = new System.Drawing.Size(729, 150);
            this.AddReminderDGV.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(81, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Reminder Name:";
            // 
            // FarmerRemNameTb
            // 
            this.FarmerRemNameTb.Location = new System.Drawing.Point(173, 68);
            this.FarmerRemNameTb.Name = "FarmerRemNameTb";
            this.FarmerRemNameTb.Size = new System.Drawing.Size(450, 20);
            this.FarmerRemNameTb.TabIndex = 11;
            // 
            // farmerremname
            // 
            this.farmerremname.HeaderText = "Reminder Name";
            this.farmerremname.MinimumWidth = 50;
            this.farmerremname.Name = "farmerremname";
            this.farmerremname.Width = 233;
            // 
            // farmerremdesc
            // 
            this.farmerremdesc.HeaderText = "Description";
            this.farmerremdesc.MinimumWidth = 50;
            this.farmerremdesc.Name = "farmerremdesc";
            this.farmerremdesc.Width = 233;
            // 
            // farmerremdate
            // 
            this.farmerremdate.HeaderText = "Date";
            this.farmerremdate.MinimumWidth = 50;
            this.farmerremdate.Name = "farmerremdate";
            this.farmerremdate.Width = 233;
            // 
            // FarmerAddReminder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 607);
            this.Controls.Add(this.FarmerRemNameTb);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.AddReminderDGV);
            this.Controls.Add(this.RemTime);
            this.Controls.Add(this.addrembtn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.FarmerRemDescTb);
            this.Controls.Add(this.label1);
            this.Name = "FarmerAddReminder";
            this.Text = "FarmerAddReminder";
            ((System.ComponentModel.ISupportInitialize)(this.AddReminderDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox FarmerRemDescTb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button addrembtn;
        private System.Windows.Forms.DateTimePicker RemTime;
        private System.Windows.Forms.DataGridView AddReminderDGV;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox FarmerRemNameTb;
        private System.Windows.Forms.DataGridViewTextBoxColumn farmerremname;
        private System.Windows.Forms.DataGridViewTextBoxColumn farmerremdesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn farmerremdate;
    }
}