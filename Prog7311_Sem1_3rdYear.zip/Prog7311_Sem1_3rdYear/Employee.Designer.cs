﻿
namespace Prog7311_Sem1_3rdYear
{
    partial class Employee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.emppagelbl = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.FarmerFNameTb = new System.Windows.Forms.TextBox();
            this.FarmerIDNumTb = new System.Windows.Forms.TextBox();
            this.FarmerContactNumTb = new System.Windows.Forms.TextBox();
            this.FarmerEmailTb = new System.Windows.Forms.TextBox();
            this.FarmerAddressTb = new System.Windows.Forms.TextBox();
            this.FarmerTypeTb = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.FarmerImagebox = new System.Windows.Forms.PictureBox();
            this.FarmerImageUPLbtn = new System.Windows.Forms.Button();
            this.FarmerSaveDescBtn = new System.Windows.Forms.Button();
            this.FarmerOptionsCB = new System.Windows.Forms.ComboBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.FarmerUNTb = new System.Windows.Forms.TextBox();
            this.FarmerPWTb = new System.Windows.Forms.TextBox();
            this.FarmerNameError = new System.Windows.Forms.ErrorProvider(this.components);
            this.FarmerIDNumError = new System.Windows.Forms.ErrorProvider(this.components);
            this.FarmerUNError = new System.Windows.Forms.ErrorProvider(this.components);
            this.FarmerPWError = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.FarmerImagebox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FarmerNameError)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FarmerIDNumError)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FarmerUNError)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FarmerPWError)).BeginInit();
            this.SuspendLayout();
            // 
            // emppagelbl
            // 
            this.emppagelbl.AutoSize = true;
            this.emppagelbl.Font = new System.Drawing.Font("Edwardian Script ITC", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emppagelbl.Location = new System.Drawing.Point(13, 13);
            this.emppagelbl.Name = "emppagelbl";
            this.emppagelbl.Size = new System.Drawing.Size(166, 35);
            this.emppagelbl.TabIndex = 0;
            this.emppagelbl.Text = "Employee Page";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(755, 25);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Sign Out";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Create New Farmer";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Farmer FullName:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Farmer ID Number:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Farmer Contact Number:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 203);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Farmer Email Address:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 230);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Farmer Address:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(27, 256);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Farmer Type:";
            // 
            // FarmerFNameTb
            // 
            this.FarmerFNameTb.Location = new System.Drawing.Point(147, 113);
            this.FarmerFNameTb.Name = "FarmerFNameTb";
            this.FarmerFNameTb.Size = new System.Drawing.Size(282, 20);
            this.FarmerFNameTb.TabIndex = 9;
            // 
            // FarmerIDNumTb
            // 
            this.FarmerIDNumTb.Location = new System.Drawing.Point(147, 141);
            this.FarmerIDNumTb.Name = "FarmerIDNumTb";
            this.FarmerIDNumTb.Size = new System.Drawing.Size(282, 20);
            this.FarmerIDNumTb.TabIndex = 10;
            // 
            // FarmerContactNumTb
            // 
            this.FarmerContactNumTb.Location = new System.Drawing.Point(147, 167);
            this.FarmerContactNumTb.Name = "FarmerContactNumTb";
            this.FarmerContactNumTb.Size = new System.Drawing.Size(282, 20);
            this.FarmerContactNumTb.TabIndex = 11;
            // 
            // FarmerEmailTb
            // 
            this.FarmerEmailTb.Location = new System.Drawing.Point(147, 196);
            this.FarmerEmailTb.Name = "FarmerEmailTb";
            this.FarmerEmailTb.Size = new System.Drawing.Size(282, 20);
            this.FarmerEmailTb.TabIndex = 12;
            // 
            // FarmerAddressTb
            // 
            this.FarmerAddressTb.Location = new System.Drawing.Point(147, 223);
            this.FarmerAddressTb.Name = "FarmerAddressTb";
            this.FarmerAddressTb.Size = new System.Drawing.Size(282, 20);
            this.FarmerAddressTb.TabIndex = 13;
            // 
            // FarmerTypeTb
            // 
            this.FarmerTypeTb.Location = new System.Drawing.Point(147, 249);
            this.FarmerTypeTb.Name = "FarmerTypeTb";
            this.FarmerTypeTb.Size = new System.Drawing.Size(282, 20);
            this.FarmerTypeTb.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(32, 368);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(93, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Add Farmer Image";
            // 
            // FarmerImagebox
            // 
            this.FarmerImagebox.Location = new System.Drawing.Point(80, 384);
            this.FarmerImagebox.Name = "FarmerImagebox";
            this.FarmerImagebox.Size = new System.Drawing.Size(451, 224);
            this.FarmerImagebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.FarmerImagebox.TabIndex = 16;
            this.FarmerImagebox.TabStop = false;
            // 
            // FarmerImageUPLbtn
            // 
            this.FarmerImageUPLbtn.Location = new System.Drawing.Point(249, 614);
            this.FarmerImageUPLbtn.Name = "FarmerImageUPLbtn";
            this.FarmerImageUPLbtn.Size = new System.Drawing.Size(75, 23);
            this.FarmerImageUPLbtn.TabIndex = 17;
            this.FarmerImageUPLbtn.Text = "Upload";
            this.FarmerImageUPLbtn.UseVisualStyleBackColor = true;
            this.FarmerImageUPLbtn.Click += new System.EventHandler(this.FarmerImageUPLbtn_Click);
            // 
            // FarmerSaveDescBtn
            // 
            this.FarmerSaveDescBtn.Location = new System.Drawing.Point(729, 673);
            this.FarmerSaveDescBtn.Name = "FarmerSaveDescBtn";
            this.FarmerSaveDescBtn.Size = new System.Drawing.Size(75, 23);
            this.FarmerSaveDescBtn.TabIndex = 18;
            this.FarmerSaveDescBtn.Text = "Save";
            this.FarmerSaveDescBtn.UseVisualStyleBackColor = true;
            this.FarmerSaveDescBtn.Click += new System.EventHandler(this.FarmerSaveDescBtn_Click);
            // 
            // FarmerOptionsCB
            // 
            this.FarmerOptionsCB.FormattingEnabled = true;
            this.FarmerOptionsCB.Items.AddRange(new object[] {
            "View Farmer stock"});
            this.FarmerOptionsCB.Location = new System.Drawing.Point(447, 25);
            this.FarmerOptionsCB.Name = "FarmerOptionsCB";
            this.FarmerOptionsCB.Size = new System.Drawing.Size(121, 21);
            this.FarmerOptionsCB.TabIndex = 19;
            this.FarmerOptionsCB.Text = "Farmer Options";
            this.FarmerOptionsCB.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(27, 282);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(93, 13);
            this.label9.TabIndex = 20;
            this.label9.Text = "Farmer Username:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(27, 309);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(91, 13);
            this.label10.TabIndex = 21;
            this.label10.Text = "Farmer Password:";
            // 
            // FarmerUNTb
            // 
            this.FarmerUNTb.Location = new System.Drawing.Point(147, 275);
            this.FarmerUNTb.Name = "FarmerUNTb";
            this.FarmerUNTb.Size = new System.Drawing.Size(282, 20);
            this.FarmerUNTb.TabIndex = 22;
            // 
            // FarmerPWTb
            // 
            this.FarmerPWTb.Location = new System.Drawing.Point(147, 302);
            this.FarmerPWTb.Name = "FarmerPWTb";
            this.FarmerPWTb.Size = new System.Drawing.Size(282, 20);
            this.FarmerPWTb.TabIndex = 23;
            // 
            // FarmerNameError
            // 
            this.FarmerNameError.ContainerControl = this;
            // 
            // FarmerIDNumError
            // 
            this.FarmerIDNumError.ContainerControl = this;
            // 
            // FarmerUNError
            // 
            this.FarmerUNError.ContainerControl = this;
            // 
            // FarmerPWError
            // 
            this.FarmerPWError.ContainerControl = this;
            // 
            // Employee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(839, 749);
            this.Controls.Add(this.FarmerPWTb);
            this.Controls.Add(this.FarmerUNTb);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.FarmerOptionsCB);
            this.Controls.Add(this.FarmerSaveDescBtn);
            this.Controls.Add(this.FarmerImageUPLbtn);
            this.Controls.Add(this.FarmerImagebox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.FarmerTypeTb);
            this.Controls.Add(this.FarmerAddressTb);
            this.Controls.Add(this.FarmerEmailTb);
            this.Controls.Add(this.FarmerContactNumTb);
            this.Controls.Add(this.FarmerIDNumTb);
            this.Controls.Add(this.FarmerFNameTb);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.emppagelbl);
            this.Name = "Employee";
            this.Text = "Employee";
            ((System.ComponentModel.ISupportInitialize)(this.FarmerImagebox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FarmerNameError)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FarmerIDNumError)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FarmerUNError)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FarmerPWError)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label emppagelbl;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox FarmerFNameTb;
        private System.Windows.Forms.TextBox FarmerIDNumTb;
        private System.Windows.Forms.TextBox FarmerContactNumTb;
        private System.Windows.Forms.TextBox FarmerEmailTb;
        private System.Windows.Forms.TextBox FarmerAddressTb;
        private System.Windows.Forms.TextBox FarmerTypeTb;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox FarmerImagebox;
        private System.Windows.Forms.Button FarmerImageUPLbtn;
        private System.Windows.Forms.Button FarmerSaveDescBtn;
        private System.Windows.Forms.ComboBox FarmerOptionsCB;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox FarmerUNTb;
        private System.Windows.Forms.TextBox FarmerPWTb;
        private System.Windows.Forms.ErrorProvider FarmerNameError;
        private System.Windows.Forms.ErrorProvider FarmerIDNumError;
        private System.Windows.Forms.ErrorProvider FarmerUNError;
        private System.Windows.Forms.ErrorProvider FarmerPWError;
    }
}