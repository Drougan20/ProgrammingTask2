﻿
namespace Prog7311_Sem1_3rdYear
{
    partial class UserRegPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.UserRegForm = new System.Windows.Forms.Label();
            this.UserRegFNamelbl = new System.Windows.Forms.Label();
            this.UserRegIDNumlbl = new System.Windows.Forms.Label();
            this.UserRegDoblbl = new System.Windows.Forms.Label();
            this.UserRegDelAddlbl = new System.Windows.Forms.Label();
            this.UserRegCitylbl = new System.Windows.Forms.Label();
            this.UserRegEmaillbl = new System.Windows.Forms.Label();
            this.UserRegContactlbl = new System.Windows.Forms.Label();
            this.UserRegEmerlbl = new System.Windows.Forms.Label();
            this.UserRegEmerFNamelbl = new System.Windows.Forms.Label();
            this.UserRegEmerContactlbl = new System.Windows.Forms.Label();
            this.UserRegFNameTb = new System.Windows.Forms.TextBox();
            this.UserRegIDNumTb = new System.Windows.Forms.TextBox();
            this.UserRegDobTb = new System.Windows.Forms.TextBox();
            this.UserRegDelAddTb = new System.Windows.Forms.TextBox();
            this.UserRegCityTb = new System.Windows.Forms.TextBox();
            this.UserRegEmailTb = new System.Windows.Forms.TextBox();
            this.UserRegContactTb = new System.Windows.Forms.TextBox();
            this.UserRegEmerFNameTb = new System.Windows.Forms.TextBox();
            this.UserRegEmerContactTb = new System.Windows.Forms.TextBox();
            this.UserRegConfBtn = new System.Windows.Forms.Button();
            this.FullNameError = new System.Windows.Forms.ErrorProvider(this.components);
            this.IDNumError = new System.Windows.Forms.ErrorProvider(this.components);
            this.DeliveryAddError = new System.Windows.Forms.ErrorProvider(this.components);
            this.ContactNumberError = new System.Windows.Forms.ErrorProvider(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.UserUNTb = new System.Windows.Forms.TextBox();
            this.UserPwTb = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.FullNameError)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IDNumError)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DeliveryAddError)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ContactNumberError)).BeginInit();
            this.SuspendLayout();
            // 
            // UserRegForm
            // 
            this.UserRegForm.AutoSize = true;
            this.UserRegForm.Font = new System.Drawing.Font("Edwardian Script ITC", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserRegForm.Location = new System.Drawing.Point(280, 34);
            this.UserRegForm.Name = "UserRegForm";
            this.UserRegForm.Size = new System.Drawing.Size(233, 41);
            this.UserRegForm.TabIndex = 0;
            this.UserRegForm.Text = "Registration Form";
            // 
            // UserRegFNamelbl
            // 
            this.UserRegFNamelbl.AutoSize = true;
            this.UserRegFNamelbl.Location = new System.Drawing.Point(37, 135);
            this.UserRegFNamelbl.Name = "UserRegFNamelbl";
            this.UserRegFNamelbl.Size = new System.Drawing.Size(54, 13);
            this.UserRegFNamelbl.TabIndex = 1;
            this.UserRegFNamelbl.Text = "FullName:";
            // 
            // UserRegIDNumlbl
            // 
            this.UserRegIDNumlbl.AutoSize = true;
            this.UserRegIDNumlbl.Location = new System.Drawing.Point(37, 157);
            this.UserRegIDNumlbl.Name = "UserRegIDNumlbl";
            this.UserRegIDNumlbl.Size = new System.Drawing.Size(64, 13);
            this.UserRegIDNumlbl.TabIndex = 2;
            this.UserRegIDNumlbl.Text = "ID Number: ";
            // 
            // UserRegDoblbl
            // 
            this.UserRegDoblbl.AutoSize = true;
            this.UserRegDoblbl.Location = new System.Drawing.Point(37, 181);
            this.UserRegDoblbl.Name = "UserRegDoblbl";
            this.UserRegDoblbl.Size = new System.Drawing.Size(69, 13);
            this.UserRegDoblbl.TabIndex = 3;
            this.UserRegDoblbl.Text = "Date of Birth:";
            // 
            // UserRegDelAddlbl
            // 
            this.UserRegDelAddlbl.AutoSize = true;
            this.UserRegDelAddlbl.Location = new System.Drawing.Point(37, 205);
            this.UserRegDelAddlbl.Name = "UserRegDelAddlbl";
            this.UserRegDelAddlbl.Size = new System.Drawing.Size(89, 13);
            this.UserRegDelAddlbl.TabIndex = 4;
            this.UserRegDelAddlbl.Text = "Delivery Address:";
            // 
            // UserRegCitylbl
            // 
            this.UserRegCitylbl.AutoSize = true;
            this.UserRegCitylbl.Location = new System.Drawing.Point(37, 229);
            this.UserRegCitylbl.Name = "UserRegCitylbl";
            this.UserRegCitylbl.Size = new System.Drawing.Size(27, 13);
            this.UserRegCitylbl.TabIndex = 5;
            this.UserRegCitylbl.Text = "City:";
            // 
            // UserRegEmaillbl
            // 
            this.UserRegEmaillbl.AutoSize = true;
            this.UserRegEmaillbl.Location = new System.Drawing.Point(37, 309);
            this.UserRegEmaillbl.Name = "UserRegEmaillbl";
            this.UserRegEmaillbl.Size = new System.Drawing.Size(76, 13);
            this.UserRegEmaillbl.TabIndex = 6;
            this.UserRegEmaillbl.Text = "Email Address:";
            // 
            // UserRegContactlbl
            // 
            this.UserRegContactlbl.AutoSize = true;
            this.UserRegContactlbl.Location = new System.Drawing.Point(37, 335);
            this.UserRegContactlbl.Name = "UserRegContactlbl";
            this.UserRegContactlbl.Size = new System.Drawing.Size(81, 13);
            this.UserRegContactlbl.TabIndex = 7;
            this.UserRegContactlbl.Text = "Phone Number:";
            // 
            // UserRegEmerlbl
            // 
            this.UserRegEmerlbl.AutoSize = true;
            this.UserRegEmerlbl.Font = new System.Drawing.Font("Edwardian Script ITC", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserRegEmerlbl.Location = new System.Drawing.Point(230, 407);
            this.UserRegEmerlbl.Name = "UserRegEmerlbl";
            this.UserRegEmerlbl.Size = new System.Drawing.Size(309, 38);
            this.UserRegEmerlbl.TabIndex = 8;
            this.UserRegEmerlbl.Text = "Emergency Contact Details";
            // 
            // UserRegEmerFNamelbl
            // 
            this.UserRegEmerFNamelbl.AutoSize = true;
            this.UserRegEmerFNamelbl.Location = new System.Drawing.Point(37, 521);
            this.UserRegEmerFNamelbl.Name = "UserRegEmerFNamelbl";
            this.UserRegEmerFNamelbl.Size = new System.Drawing.Size(54, 13);
            this.UserRegEmerFNamelbl.TabIndex = 9;
            this.UserRegEmerFNamelbl.Text = "FullName:";
            // 
            // UserRegEmerContactlbl
            // 
            this.UserRegEmerContactlbl.AutoSize = true;
            this.UserRegEmerContactlbl.Location = new System.Drawing.Point(37, 547);
            this.UserRegEmerContactlbl.Name = "UserRegEmerContactlbl";
            this.UserRegEmerContactlbl.Size = new System.Drawing.Size(81, 13);
            this.UserRegEmerContactlbl.TabIndex = 10;
            this.UserRegEmerContactlbl.Text = "Phone Number:";
            // 
            // UserRegFNameTb
            // 
            this.UserRegFNameTb.Location = new System.Drawing.Point(138, 132);
            this.UserRegFNameTb.Name = "UserRegFNameTb";
            this.UserRegFNameTb.Size = new System.Drawing.Size(254, 20);
            this.UserRegFNameTb.TabIndex = 11;
            // 
            // UserRegIDNumTb
            // 
            this.UserRegIDNumTb.Location = new System.Drawing.Point(138, 157);
            this.UserRegIDNumTb.Name = "UserRegIDNumTb";
            this.UserRegIDNumTb.Size = new System.Drawing.Size(254, 20);
            this.UserRegIDNumTb.TabIndex = 12;
            // 
            // UserRegDobTb
            // 
            this.UserRegDobTb.Location = new System.Drawing.Point(138, 181);
            this.UserRegDobTb.Name = "UserRegDobTb";
            this.UserRegDobTb.Size = new System.Drawing.Size(254, 20);
            this.UserRegDobTb.TabIndex = 13;
            // 
            // UserRegDelAddTb
            // 
            this.UserRegDelAddTb.Location = new System.Drawing.Point(138, 205);
            this.UserRegDelAddTb.Name = "UserRegDelAddTb";
            this.UserRegDelAddTb.Size = new System.Drawing.Size(254, 20);
            this.UserRegDelAddTb.TabIndex = 14;
            // 
            // UserRegCityTb
            // 
            this.UserRegCityTb.Location = new System.Drawing.Point(138, 229);
            this.UserRegCityTb.Name = "UserRegCityTb";
            this.UserRegCityTb.Size = new System.Drawing.Size(254, 20);
            this.UserRegCityTb.TabIndex = 15;
            // 
            // UserRegEmailTb
            // 
            this.UserRegEmailTb.Location = new System.Drawing.Point(138, 309);
            this.UserRegEmailTb.Name = "UserRegEmailTb";
            this.UserRegEmailTb.Size = new System.Drawing.Size(254, 20);
            this.UserRegEmailTb.TabIndex = 16;
            // 
            // UserRegContactTb
            // 
            this.UserRegContactTb.Location = new System.Drawing.Point(138, 335);
            this.UserRegContactTb.Name = "UserRegContactTb";
            this.UserRegContactTb.Size = new System.Drawing.Size(254, 20);
            this.UserRegContactTb.TabIndex = 17;
            // 
            // UserRegEmerFNameTb
            // 
            this.UserRegEmerFNameTb.Location = new System.Drawing.Point(138, 521);
            this.UserRegEmerFNameTb.Name = "UserRegEmerFNameTb";
            this.UserRegEmerFNameTb.Size = new System.Drawing.Size(254, 20);
            this.UserRegEmerFNameTb.TabIndex = 18;
            // 
            // UserRegEmerContactTb
            // 
            this.UserRegEmerContactTb.Location = new System.Drawing.Point(138, 547);
            this.UserRegEmerContactTb.Name = "UserRegEmerContactTb";
            this.UserRegEmerContactTb.Size = new System.Drawing.Size(254, 20);
            this.UserRegEmerContactTb.TabIndex = 19;
            // 
            // UserRegConfBtn
            // 
            this.UserRegConfBtn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.UserRegConfBtn.ForeColor = System.Drawing.SystemColors.InfoText;
            this.UserRegConfBtn.Location = new System.Drawing.Point(317, 630);
            this.UserRegConfBtn.Name = "UserRegConfBtn";
            this.UserRegConfBtn.Size = new System.Drawing.Size(162, 29);
            this.UserRegConfBtn.TabIndex = 20;
            this.UserRegConfBtn.Text = "Confirm";
            this.UserRegConfBtn.UseVisualStyleBackColor = false;
            this.UserRegConfBtn.Click += new System.EventHandler(this.UserRegConfBtn_Click);
            // 
            // FullNameError
            // 
            this.FullNameError.ContainerControl = this;
            // 
            // IDNumError
            // 
            this.IDNumError.ContainerControl = this;
            // 
            // DeliveryAddError
            // 
            this.DeliveryAddError.ContainerControl = this;
            // 
            // ContactNumberError
            // 
            this.ContactNumberError.ContainerControl = this;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 283);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 21;
            this.label1.Text = "Password:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 256);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 22;
            this.label2.Text = "Username:";
            // 
            // UserUNTb
            // 
            this.UserUNTb.Location = new System.Drawing.Point(138, 256);
            this.UserUNTb.Name = "UserUNTb";
            this.UserUNTb.Size = new System.Drawing.Size(254, 20);
            this.UserUNTb.TabIndex = 23;
            // 
            // UserPwTb
            // 
            this.UserPwTb.Location = new System.Drawing.Point(138, 283);
            this.UserPwTb.Name = "UserPwTb";
            this.UserPwTb.Size = new System.Drawing.Size(254, 20);
            this.UserPwTb.TabIndex = 24;
            // 
            // UserRegPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(800, 749);
            this.Controls.Add(this.UserPwTb);
            this.Controls.Add(this.UserUNTb);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.UserRegConfBtn);
            this.Controls.Add(this.UserRegEmerContactTb);
            this.Controls.Add(this.UserRegEmerFNameTb);
            this.Controls.Add(this.UserRegContactTb);
            this.Controls.Add(this.UserRegEmailTb);
            this.Controls.Add(this.UserRegCityTb);
            this.Controls.Add(this.UserRegDelAddTb);
            this.Controls.Add(this.UserRegDobTb);
            this.Controls.Add(this.UserRegIDNumTb);
            this.Controls.Add(this.UserRegFNameTb);
            this.Controls.Add(this.UserRegEmerContactlbl);
            this.Controls.Add(this.UserRegEmerFNamelbl);
            this.Controls.Add(this.UserRegEmerlbl);
            this.Controls.Add(this.UserRegContactlbl);
            this.Controls.Add(this.UserRegEmaillbl);
            this.Controls.Add(this.UserRegCitylbl);
            this.Controls.Add(this.UserRegDelAddlbl);
            this.Controls.Add(this.UserRegDoblbl);
            this.Controls.Add(this.UserRegIDNumlbl);
            this.Controls.Add(this.UserRegFNamelbl);
            this.Controls.Add(this.UserRegForm);
            this.Name = "UserRegPage";
            this.Text = "RegPage";
            ((System.ComponentModel.ISupportInitialize)(this.FullNameError)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IDNumError)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DeliveryAddError)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ContactNumberError)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label UserRegForm;
        private System.Windows.Forms.Label UserRegFNamelbl;
        private System.Windows.Forms.Label UserRegIDNumlbl;
        private System.Windows.Forms.Label UserRegDoblbl;
        private System.Windows.Forms.Label UserRegDelAddlbl;
        private System.Windows.Forms.Label UserRegCitylbl;
        private System.Windows.Forms.Label UserRegEmaillbl;
        private System.Windows.Forms.Label UserRegContactlbl;
        private System.Windows.Forms.Label UserRegEmerlbl;
        private System.Windows.Forms.Label UserRegEmerFNamelbl;
        private System.Windows.Forms.Label UserRegEmerContactlbl;
        private System.Windows.Forms.TextBox UserRegFNameTb;
        private System.Windows.Forms.TextBox UserRegIDNumTb;
        private System.Windows.Forms.TextBox UserRegDobTb;
        private System.Windows.Forms.TextBox UserRegDelAddTb;
        private System.Windows.Forms.TextBox UserRegCityTb;
        private System.Windows.Forms.TextBox UserRegEmailTb;
        private System.Windows.Forms.TextBox UserRegContactTb;
        private System.Windows.Forms.TextBox UserRegEmerFNameTb;
        private System.Windows.Forms.TextBox UserRegEmerContactTb;
        private System.Windows.Forms.Button UserRegConfBtn;
        private System.Windows.Forms.ErrorProvider FullNameError;
        private System.Windows.Forms.ErrorProvider IDNumError;
        private System.Windows.Forms.ErrorProvider DeliveryAddError;
        private System.Windows.Forms.ErrorProvider ContactNumberError;
        private System.Windows.Forms.TextBox UserPwTb;
        private System.Windows.Forms.TextBox UserUNTb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}