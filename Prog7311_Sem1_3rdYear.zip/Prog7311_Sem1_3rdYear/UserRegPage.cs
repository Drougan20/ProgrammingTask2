﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Prog7311_Sem1_3rdYear
{
    public partial class UserRegPage : Form
    {
        SqlConnection scn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\MohammadDb.mdf;Integrated Security=True");
        SqlCommand scm = new SqlCommand();
        
        public UserRegPage()
        {
            InitializeComponent();
        }
       
        private void UserRegConfBtn_Click(object sender, EventArgs e)
        {
            scn.Open();
            string add = "Insert into UserRegTable(UserFullName,UserIDNumber,UserDateOfBirth,UserDeliveryAddress,UserCity,UserName,UserPassword,UserEmailAddress,UserPhoneNumber,UserEmergencyName,UserEmergencyContact)values('" +
           UserRegFNameTb.Text.Trim().ToString() + "','" + UserRegIDNumTb.Text.Trim().ToString() + "','" + UserRegDobTb.Text.Trim().ToString() + "','"
           + UserRegDelAddTb.Text.Trim().ToString() + "','" + UserRegCityTb.Text.Trim().ToString() + "','" + UserUNTb.Text.Trim().ToString() +
           "','" + UserPwTb.Text.Trim().ToString() + "','" + UserRegEmailTb.Text.Trim().ToString() + "','" + UserRegContactTb.Text.Trim().ToString() +
           "','" + UserRegEmerFNameTb.Text.Trim().ToString() +"','" + UserRegEmerContactTb.Text.Trim().ToString() +"')";

            if (UserRegFNameTb.Text.Trim() == string.Empty)
            {
                UserRegFNameTb.Focus();
                FullNameError.SetError(UserRegFNameTb,"Please Enter a value");
            }
            if (UserRegContactTb.Text.Trim() == string.Empty)
            {
                UserRegContactTb.Focus();
                ContactNumberError.SetError(UserRegContactTb, "Please Enter a value");
            }
            if (UserRegIDNumTb.Text.Trim() == string.Empty)
            {
                UserRegIDNumTb.Focus();
                IDNumError.SetError(UserRegIDNumTb, "Please Enter a value");
            }
            if (UserRegDelAddTb.Text.Trim() == string.Empty)
            {
                UserRegDelAddTb.Focus();
                DeliveryAddError.SetError(UserRegDelAddTb, "Please Enter a value");
            }

            else
            {
                
                scm = new SqlCommand(add, scn);
                scm.ExecuteNonQuery();
                MessageBox.Show(UserRegFNameTb.Text + ", you have been Successfully Added to Farm Central");
                this.Close();
                FarmCentralHomePage hp = new FarmCentralHomePage();
                hp.Show();
            }
        }
    }
}
