﻿
namespace Prog7311_Sem1_3rdYear
{
    partial class Farmer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.FarmerSignOutBtn = new System.Windows.Forms.Button();
            this.EventRemCB = new System.Windows.Forms.ComboBox();
            this.addprodCB = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Edwardian Script ITC", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "Farmer Page";
            // 
            // FarmerSignOutBtn
            // 
            this.FarmerSignOutBtn.BackColor = System.Drawing.Color.White;
            this.FarmerSignOutBtn.Location = new System.Drawing.Point(1022, 25);
            this.FarmerSignOutBtn.Name = "FarmerSignOutBtn";
            this.FarmerSignOutBtn.Size = new System.Drawing.Size(75, 23);
            this.FarmerSignOutBtn.TabIndex = 1;
            this.FarmerSignOutBtn.Text = "Sign Out";
            this.FarmerSignOutBtn.UseVisualStyleBackColor = false;
            this.FarmerSignOutBtn.Click += new System.EventHandler(this.FarmerSignOutBtn_Click);
            // 
            // EventRemCB
            // 
            this.EventRemCB.FormattingEnabled = true;
            this.EventRemCB.Items.AddRange(new object[] {
            "Add A Reminder",
            "Remove A Reminder"});
            this.EventRemCB.Location = new System.Drawing.Point(269, 24);
            this.EventRemCB.Name = "EventRemCB";
            this.EventRemCB.Size = new System.Drawing.Size(121, 21);
            this.EventRemCB.TabIndex = 2;
            this.EventRemCB.Text = "Reminders/Events";
            this.EventRemCB.SelectedIndexChanged += new System.EventHandler(this.EventRemCB_SelectedIndexChanged);
            // 
            // addprodCB
            // 
            this.addprodCB.FormattingEnabled = true;
            this.addprodCB.Items.AddRange(new object[] {
            "Add A Product",
            "Remove A Product"});
            this.addprodCB.Location = new System.Drawing.Point(468, 22);
            this.addprodCB.Name = "addprodCB";
            this.addprodCB.Size = new System.Drawing.Size(146, 21);
            this.addprodCB.TabIndex = 3;
            this.addprodCB.Text = "Product";
            this.addprodCB.SelectedIndexChanged += new System.EventHandler(this.addprodCB_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(59, 179);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(147, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "View Reminders";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(59, 308);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(147, 23);
            this.button2.TabIndex = 5;
            this.button2.Text = "View My Products";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Farmer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1149, 749);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.addprodCB);
            this.Controls.Add(this.EventRemCB);
            this.Controls.Add(this.FarmerSignOutBtn);
            this.Controls.Add(this.label1);
            this.Name = "Farmer";
            this.Text = "Farmer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button FarmerSignOutBtn;
        private System.Windows.Forms.ComboBox EventRemCB;
        private System.Windows.Forms.ComboBox addprodCB;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}