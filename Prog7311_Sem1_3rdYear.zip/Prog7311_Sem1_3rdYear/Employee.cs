﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Configuration;
using System.Data.SqlClient;

namespace Prog7311_Sem1_3rdYear
{

    public partial class Employee : Form
    {
       SqlConnection Empscn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\JALAAL\\source\\repos\\Prog7311_Sem1_3rdYear\\bin\\Debug\\MohammmadDb.mdf;Integrated Security=True");
        SqlCommand Empscm = new SqlCommand();
        SqlDataAdapter sda = new SqlDataAdapter();
        public Employee()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            String farmerops = FarmerOptionsCB.Text;

            if(farmerops.Equals("View Farmer stock"))
            {
                EMPFarmerSpecifics fs = new EMPFarmerSpecifics();
                fs.Show();
            }
        }

        private void FarmerImageUPLbtn_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            string filepath = openFileDialog1.FileName;
            FarmerImagebox.Image = Image.FromFile(filepath);
        }

        private void FarmerSaveDescBtn_Click(object sender, EventArgs e)
        {

           
            if (FarmerFNameTb.Text.Trim() == string.Empty)
            {
                FarmerFNameTb.Focus();
                FarmerNameError.SetError(FarmerFNameTb, "Please Enter a value");
            }
            if (FarmerIDNumTb.Text.Trim() == string.Empty)
            {
                FarmerIDNumTb.Focus();
                FarmerIDNumError.SetError(FarmerIDNumTb, "Please Enter a value");
            }
            if (FarmerUNTb.Text.Trim() == string.Empty)
            {
                FarmerUNTb.Focus();
                FarmerUNError.SetError(FarmerUNTb, "Please Enter a value");
            }
            if (FarmerPWTb.Text.Trim() == string.Empty)
            {
                FarmerPWTb.Focus();
                FarmerPWError.SetError(FarmerPWTb, "Please Enter a value");
            }

            else
            
            {
                try
                    {
                    Empscn.Open();
                    Empscm = new SqlCommand("Insert into FarmerRegTabel(FarmerFullName,FarmerIDNumber,FarmerAddress,FarmerType,FarmerUsername,FarmerPassword,FarmerEmailAddress)values('" +
                    FarmerFNameTb.Text.Trim().ToString() + "','" + FarmerIDNumTb.Text.Trim().ToString() + "','"
                    + "','" + FarmerAddressTb.Text.Trim().ToString() + "','" + FarmerTypeTb.Text.Trim().ToString() + "','" + FarmerUNTb.Text.Trim().ToString() + "','"
                    + FarmerPWTb.Text.Trim().ToString() + FarmerEmailTb.Text.Trim().ToString() + "')", Empscn);
                    Empscm.ExecuteScalar();
                    MessageBox.Show("A new farmer has been successfully added");
                    Empscn.Close();
                }
                catch(Exception)
                {
                    throw;
                }
                
               
            }
            
        }
    }
}

//sda.InsertCommand = new SqlCommand("INSERT INTO FarmerRegTabel (FarmerFullName,FarmerIDNumber) VALUES (@FarmerFullName,@FarmerIDNumber)",Empscn);
//sda.InsertCommand.Parameters.AddWithValue("@FarmerFullName",FarmerFNameTb.Text);
//sda.InsertCommand.Parameters.AddWithValue("@FarmerIDNumber",FarmerIDNumTb.Text);
//sda.InsertCommand.ExecuteNonQuery();
//,FarmerContactNumber  + FarmerContactNumTb.Text.Trim().ToString() 

//  string addfarmer = "Insert into FarmerRegTabel(FarmerFullName,FarmerIDNumber,FarmerContactNumber,FarmerAddress,FarmerType,FarmerUsername,FarmerPassword,FarmerEmailAddress)values('" +
//FarmerFNameTb.Text.Trim().ToString() + "','" + FarmerIDNumTb.Text.Trim().ToString() + "','" + FarmerContactNumTb.Text.Trim().ToString() + "','"
//+ "','" + FarmerAddressTb.Text.Trim().ToString() +"','" + FarmerTypeTb.Text.Trim().ToString() + "','" + FarmerUNTb.Text.Trim().ToString() + "','" 
//+ FarmerPWTb.Text.Trim().ToString() + FarmerEmailTb.Text.Trim().ToString()+ "')";
//AttachDbFilename=C:\\Users\\JALAAL\\source\\repos\\Prog7311_Sem1_3rdYear\\MohammmadDb.mdf
//|DataDirectory|\\MohammmadDb.mdf