﻿
namespace Prog7311_Sem1_3rdYear
{
    partial class FarmCentralHomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.FCHomePagelbl = new System.Windows.Forms.Label();
            this.SignOutbtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.mortarpic = new System.Windows.Forms.PictureBox();
            this.claypic = new System.Windows.Forms.PictureBox();
            this.BrickLB = new System.Windows.Forms.ListBox();
            this.MortarLB = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.mortarpic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.claypic)).BeginInit();
            this.SuspendLayout();
            // 
            // FCHomePagelbl
            // 
            this.FCHomePagelbl.AutoSize = true;
            this.FCHomePagelbl.Font = new System.Drawing.Font("Edwardian Script ITC", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FCHomePagelbl.Location = new System.Drawing.Point(302, 9);
            this.FCHomePagelbl.Name = "FCHomePagelbl";
            this.FCHomePagelbl.Size = new System.Drawing.Size(279, 35);
            this.FCHomePagelbl.TabIndex = 0;
            this.FCHomePagelbl.Text = "Farm Central Home Page";
            this.FCHomePagelbl.Click += new System.EventHandler(this.FCHomePagelbl_Click);
            // 
            // SignOutbtn
            // 
            this.SignOutbtn.BackColor = System.Drawing.Color.White;
            this.SignOutbtn.Location = new System.Drawing.Point(1227, 13);
            this.SignOutbtn.Name = "SignOutbtn";
            this.SignOutbtn.Size = new System.Drawing.Size(95, 25);
            this.SignOutbtn.TabIndex = 1;
            this.SignOutbtn.Text = "Sign Out";
            this.SignOutbtn.UseVisualStyleBackColor = false;
            this.SignOutbtn.Click += new System.EventHandler(this.SignOutbtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Brick";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(526, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Mortar";
            // 
            // mortarpic
            // 
            this.mortarpic.Image = global::Prog7311_Sem1_3rdYear.Properties.Resources.mortar;
            this.mortarpic.Location = new System.Drawing.Point(502, 104);
            this.mortarpic.Name = "mortarpic";
            this.mortarpic.Size = new System.Drawing.Size(279, 188);
            this.mortarpic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.mortarpic.TabIndex = 3;
            this.mortarpic.TabStop = false;
            // 
            // claypic
            // 
            this.claypic.Image = global::Prog7311_Sem1_3rdYear.Properties.Resources.brick;
            this.claypic.Location = new System.Drawing.Point(22, 104);
            this.claypic.Name = "claypic";
            this.claypic.Size = new System.Drawing.Size(279, 188);
            this.claypic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.claypic.TabIndex = 2;
            this.claypic.TabStop = false;
            this.claypic.Click += new System.EventHandler(this.claypic_Click);
            // 
            // BrickLB
            // 
            this.BrickLB.FormattingEnabled = true;
            this.BrickLB.Location = new System.Drawing.Point(22, 358);
            this.BrickLB.Name = "BrickLB";
            this.BrickLB.Size = new System.Drawing.Size(387, 368);
            this.BrickLB.TabIndex = 6;
            // 
            // MortarLB
            // 
            this.MortarLB.FormattingEnabled = true;
            this.MortarLB.Location = new System.Drawing.Point(502, 358);
            this.MortarLB.Name = "MortarLB";
            this.MortarLB.Size = new System.Drawing.Size(387, 368);
            this.MortarLB.TabIndex = 7;
            // 
            // FarmCentralHomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.MortarLB);
            this.Controls.Add(this.BrickLB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.mortarpic);
            this.Controls.Add(this.claypic);
            this.Controls.Add(this.SignOutbtn);
            this.Controls.Add(this.FCHomePagelbl);
            this.Name = "FarmCentralHomePage";
            this.Text = "FarmCentralHomePage";
            ((System.ComponentModel.ISupportInitialize)(this.mortarpic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.claypic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label FCHomePagelbl;
        private System.Windows.Forms.Button SignOutbtn;
        private System.Windows.Forms.PictureBox claypic;
        private System.Windows.Forms.PictureBox mortarpic;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox BrickLB;
        private System.Windows.Forms.ListBox MortarLB;
    }
}