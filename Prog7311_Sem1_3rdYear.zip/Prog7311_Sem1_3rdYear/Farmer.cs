﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Prog7311_Sem1_3rdYear
{
    public partial class Farmer : Form
    {
        SqlConnection prodscn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\JALAAL\\source\\repos\\Prog7311_Sem1_3rdYear\\bin\\Debug\\MohammmadDb.mdf;Integrated Security=True");
        SqlCommand cmd;

        public Farmer()
        {
            InitializeComponent();
        }

        private void FarmerSignOutBtn_Click(object sender, EventArgs e)
        {
            this.Close();
            OpeningPage op = new OpeningPage();
            op.Show();
        }

        private void EventRemCB_SelectedIndexChanged(object sender, EventArgs e)
        {//Add A Reminder
           // Remove A Reminder
            //Edit A Reminder
            string cbdetails = "";

            cbdetails = this.EventRemCB.Text;

            if(cbdetails.Equals("Add A Reminder"))
            {
                FarmerAddReminder far = new FarmerAddReminder();
                far.Show();

            }
        }

        private void addprodCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            String addprodCB = "";

            if (addprodCB.Equals("Add A Product"))
            {
                FarmerAddProduct fap = new FarmerAddProduct();
                fap.Show();
            }

            if(addprodCB.Equals("Remove A Product"))
            {
                FarmerDeleteProduct fdp = new FarmerDeleteProduct();
                fdp.Show();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            prodscn.Open();
            SqlCommand viewprod = new SqlCommand();
            string vp = "Select * from FarmerProdTable";
            viewprod = new SqlCommand(vp,prodscn);
            viewprod.ExecuteNonQuery();
            string display = viewprod.ToString();
            MessageBox.Show(display);
            prodscn.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            prodscn.Open();
            string vrem = "Select * from FarmerReminderTable";
            cmd = new SqlCommand(vrem, prodscn);
            cmd.ExecuteNonQuery();
            string dis = cmd.ToString();
            MessageBox.Show(dis);
            prodscn.Close();
        }
    }
}
