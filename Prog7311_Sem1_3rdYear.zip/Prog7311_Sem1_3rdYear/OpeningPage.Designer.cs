﻿
namespace Prog7311_Sem1_3rdYear
{
    partial class OpeningPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OpeningPage));
            this.label1 = new System.Windows.Forms.Label();
            this.LoginRegCB = new System.Windows.Forms.ComboBox();
            this.FarmCentralDesclbl1 = new System.Windows.Forms.Label();
            this.FarmCentalDesclbl2 = new System.Windows.Forms.Label();
            this.FarmCentralDesclbl3 = new System.Windows.Forms.Label();
            this.FarmCentralcontact = new System.Windows.Forms.Label();
            this.FarmCentralLoc = new System.Windows.Forms.LinkLabel();
            this.farmcentralemail = new System.Windows.Forms.PictureBox();
            this.LocationPic = new System.Windows.Forms.PictureBox();
            this.FarmCentralC = new System.Windows.Forms.PictureBox();
            this.FarmCentralDisplay = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.farmcentralemail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LocationPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FarmCentralC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FarmCentralDisplay)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Font = new System.Drawing.Font("Edwardian Script ITC", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label1.ImageKey = "(none)";
            this.label1.Location = new System.Drawing.Point(364, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(185, 41);
            this.label1.TabIndex = 0;
            this.label1.Text = "Farm Central";
            // 
            // LoginRegCB
            // 
            this.LoginRegCB.BackColor = System.Drawing.SystemColors.Window;
            this.LoginRegCB.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoginRegCB.ForeColor = System.Drawing.SystemColors.Desktop;
            this.LoginRegCB.FormattingEnabled = true;
            this.LoginRegCB.Items.AddRange(new object[] {
            "Register",
            "Login"});
            this.LoginRegCB.Location = new System.Drawing.Point(807, 32);
            this.LoginRegCB.Name = "LoginRegCB";
            this.LoginRegCB.Size = new System.Drawing.Size(205, 32);
            this.LoginRegCB.TabIndex = 1;
            this.LoginRegCB.Text = "Join the Farm Family";
            this.LoginRegCB.SelectedIndexChanged += new System.EventHandler(this.LoginRegCB_SelectedIndexChanged);
            // 
            // FarmCentralDesclbl1
            // 
            this.FarmCentralDesclbl1.AutoSize = true;
            this.FarmCentralDesclbl1.BackColor = System.Drawing.Color.Transparent;
            this.FarmCentralDesclbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FarmCentralDesclbl1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.FarmCentralDesclbl1.Location = new System.Drawing.Point(12, 405);
            this.FarmCentralDesclbl1.Name = "FarmCentralDesclbl1";
            this.FarmCentralDesclbl1.Size = new System.Drawing.Size(1312, 54);
            this.FarmCentralDesclbl1.TabIndex = 3;
            this.FarmCentralDesclbl1.Text = resources.GetString("FarmCentralDesclbl1.Text");
            // 
            // FarmCentalDesclbl2
            // 
            this.FarmCentalDesclbl2.AutoSize = true;
            this.FarmCentalDesclbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.FarmCentalDesclbl2.Location = new System.Drawing.Point(13, 477);
            this.FarmCentalDesclbl2.Name = "FarmCentalDesclbl2";
            this.FarmCentalDesclbl2.Size = new System.Drawing.Size(1200, 54);
            this.FarmCentalDesclbl2.TabIndex = 5;
            this.FarmCentalDesclbl2.Text = resources.GetString("FarmCentalDesclbl2.Text");
            // 
            // FarmCentralDesclbl3
            // 
            this.FarmCentralDesclbl3.AutoSize = true;
            this.FarmCentralDesclbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.FarmCentralDesclbl3.Location = new System.Drawing.Point(13, 543);
            this.FarmCentralDesclbl3.Name = "FarmCentralDesclbl3";
            this.FarmCentralDesclbl3.Size = new System.Drawing.Size(1315, 72);
            this.FarmCentralDesclbl3.TabIndex = 6;
            this.FarmCentralDesclbl3.Text = resources.GetString("FarmCentralDesclbl3.Text");
            // 
            // FarmCentralcontact
            // 
            this.FarmCentralcontact.AutoSize = true;
            this.FarmCentralcontact.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.FarmCentralcontact.Location = new System.Drawing.Point(108, 652);
            this.FarmCentralcontact.Name = "FarmCentralcontact";
            this.FarmCentralcontact.Size = new System.Drawing.Size(121, 18);
            this.FarmCentralcontact.TabIndex = 8;
            this.FarmCentralcontact.Text = "+ 27 11 685 0214";
            // 
            // FarmCentralLoc
            // 
            this.FarmCentralLoc.AutoSize = true;
            this.FarmCentralLoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.FarmCentralLoc.Location = new System.Drawing.Point(644, 652);
            this.FarmCentralLoc.Name = "FarmCentralLoc";
            this.FarmCentralLoc.Size = new System.Drawing.Size(94, 18);
            this.FarmCentralLoc.TabIndex = 10;
            this.FarmCentralLoc.TabStop = true;
            this.FarmCentralLoc.Text = "Farm Central";
            this.FarmCentralLoc.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.FarmCentralLocation_link);
            // 
            // farmcentralemail
            // 
            this.farmcentralemail.Image = global::Prog7311_Sem1_3rdYear.Properties.Resources.emailicon;
            this.farmcentralemail.Location = new System.Drawing.Point(1031, 632);
            this.farmcentralemail.Name = "farmcentralemail";
            this.farmcentralemail.Size = new System.Drawing.Size(86, 60);
            this.farmcentralemail.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.farmcentralemail.TabIndex = 11;
            this.farmcentralemail.TabStop = false;
            // 
            // LocationPic
            // 
            this.LocationPic.Image = global::Prog7311_Sem1_3rdYear.Properties.Resources.LocationImg;
            this.LocationPic.Location = new System.Drawing.Point(552, 632);
            this.LocationPic.Name = "LocationPic";
            this.LocationPic.Size = new System.Drawing.Size(86, 60);
            this.LocationPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.LocationPic.TabIndex = 9;
            this.LocationPic.TabStop = false;
            this.LocationPic.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // FarmCentralC
            // 
            this.FarmCentralC.Image = global::Prog7311_Sem1_3rdYear.Properties.Resources.phoneIcon;
            this.FarmCentralC.Location = new System.Drawing.Point(16, 632);
            this.FarmCentralC.Name = "FarmCentralC";
            this.FarmCentralC.Size = new System.Drawing.Size(86, 60);
            this.FarmCentralC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.FarmCentralC.TabIndex = 7;
            this.FarmCentralC.TabStop = false;
            // 
            // FarmCentralDisplay
            // 
            this.FarmCentralDisplay.Image = global::Prog7311_Sem1_3rdYear.Properties.Resources.farm_central___Copy;
            this.FarmCentralDisplay.Location = new System.Drawing.Point(345, 92);
            this.FarmCentralDisplay.Name = "FarmCentralDisplay";
            this.FarmCentralDisplay.Size = new System.Drawing.Size(611, 310);
            this.FarmCentralDisplay.TabIndex = 4;
            this.FarmCentralDisplay.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label3.Location = new System.Drawing.Point(1123, 652);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(170, 18);
            this.label3.TabIndex = 12;
            this.label3.Text = "info@FarmCentral.co.za";
            // 
            // OpeningPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(17F, 35F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.farmcentralemail);
            this.Controls.Add(this.FarmCentralLoc);
            this.Controls.Add(this.LocationPic);
            this.Controls.Add(this.FarmCentralcontact);
            this.Controls.Add(this.FarmCentralC);
            this.Controls.Add(this.FarmCentralDesclbl3);
            this.Controls.Add(this.FarmCentalDesclbl2);
            this.Controls.Add(this.FarmCentralDisplay);
            this.Controls.Add(this.FarmCentralDesclbl1);
            this.Controls.Add(this.LoginRegCB);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Edwardian Script ITC", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(8);
            this.Name = "OpeningPage";
            this.Text = "OpeningPage";
            this.TransparencyKey = System.Drawing.Color.LightGray;
            ((System.ComponentModel.ISupportInitialize)(this.farmcentralemail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LocationPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FarmCentralC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FarmCentralDisplay)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox LoginRegCB;
        private System.Windows.Forms.Label FarmCentralDesclbl1;
        private System.Windows.Forms.PictureBox FarmCentralDisplay;
        private System.Windows.Forms.Label FarmCentalDesclbl2;
        private System.Windows.Forms.Label FarmCentralDesclbl3;
        private System.Windows.Forms.PictureBox FarmCentralC;
        private System.Windows.Forms.Label FarmCentralcontact;
        private System.Windows.Forms.PictureBox LocationPic;
        private System.Windows.Forms.LinkLabel FarmCentralLoc;
        private System.Windows.Forms.PictureBox farmcentralemail;
        private System.Windows.Forms.Label label3;
    }
}