﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog7311_Sem1_3rdYear
{
    public partial class OpeningPage : Form
    {
        public OpeningPage()
        {
            InitializeComponent();
            
        }

       
        private void LoginRegCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            string display = this.LoginRegCB.Text;

            if(display.Equals("Login"))
            {
                LoginPage lp = new LoginPage();
                lp.Show();
            }

            if(display.Equals("Register"))
            {
                UserRegPage rp = new UserRegPage();
                rp.Show();
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void FarmCentralLocation_link(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start
            ("https://www.google.com/maps/place/113+Dickon+Hall+Cres,+Rocky+Drift,+White+River,+1240/@-25.3752751,30.9735313,17z/data=!3m1!4b1!4m5!3m4!1s0x1ee833f78cb510ad:0x43c833526d6e335d!8m2!3d-25.37528!4d30.97572");
        }
    }
}
