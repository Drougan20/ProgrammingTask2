﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Prog7311_Sem1_3rdYear
{
    class EmpRegTb
    {
        public void AddFarmer()
        {

        }
    }
}
