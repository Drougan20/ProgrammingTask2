﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Prog7311_Sem1_3rdYear
{
    public partial class FarmerAddProduct : Form
    {
        SqlConnection ursqc = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\MohammadDb.mdf;Integrated Security=True");
        SqlCommand urscm = new SqlCommand();
        public FarmerAddProduct()
        {
            InitializeComponent();
        }

        private void FarmerAddProdbtn_Click(object sender, EventArgs e)
        {
            ursqc.Open();

            string insertstatement;
            insertstatement = "insert into FarmerProdTable(ProdName,ProdQuantity,ProdID,CostPrice,SellingPrice,SuppName,SuppID,SuppAddress)values('" +
           FarmerProdNameTb.Text.Trim().ToString() + "','" + FarmerProdQtyTb.Text.Trim().ToString() + "','" + FarmerProdIdTb.Text.Trim().ToString() + "','"
         + FarmerProdDescTb.Text.Trim().ToString()  + "','" + FarmerProdCPTb.Text.Trim().ToString() +"','" + FarmerProdSPTb.Text.Trim().ToString() + "','"
         + FarmerProdSuppNameTb.Text.Trim().ToString() + "','" + FarmerProdSuppIDTb.Text.Trim().ToString() + "','" + FarmerProdSuppAddTb.Text.Trim().ToString() + "')";


            if (FarmerProdNameTb.Text.Trim() == string.Empty)
            {
                FarmerProdNameTb.Focus();
                ProdNameError.SetError(FarmerProdNameTb, "Please Enter a value");
            }
            if (FarmerProdIdTb.Text.Trim() == string.Empty)
            {
                FarmerProdIdTb.Focus();
                ProdIDError.SetError(FarmerProdIdTb, "Please Enter a value");
            }
            if (FarmerProdSPTb.Text.Trim() == string.Empty)
            {
                FarmerProdSPTb.Focus();
                ProdSellPriceError.SetError(FarmerProdSPTb, "Please Enter a value");
            }

            else
            {
                urscm = new SqlCommand(insertstatement, ursqc);
                urscm.ExecuteNonQuery();
                MessageBox.Show("The product has been successfully added");

            }

        }
    }
}
