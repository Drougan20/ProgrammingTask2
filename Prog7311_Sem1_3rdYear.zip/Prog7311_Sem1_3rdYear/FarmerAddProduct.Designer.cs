﻿
namespace Prog7311_Sem1_3rdYear
{
    partial class FarmerAddProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.FarmerAddImgbtn = new System.Windows.Forms.Button();
            this.FarmerAddProdbtn = new System.Windows.Forms.Button();
            this.FarmerProdNameTb = new System.Windows.Forms.TextBox();
            this.FarmerProdQtyTb = new System.Windows.Forms.TextBox();
            this.FarmerProdIdTb = new System.Windows.Forms.TextBox();
            this.FarmerProdDescTb = new System.Windows.Forms.TextBox();
            this.FarmerProdCPTb = new System.Windows.Forms.TextBox();
            this.FarmerProdSPTb = new System.Windows.Forms.TextBox();
            this.FarmerProdSuppNameTb = new System.Windows.Forms.TextBox();
            this.FarmerProdSuppIDTb = new System.Windows.Forms.TextBox();
            this.FarmerProdSuppAddTb = new System.Windows.Forms.TextBox();
            this.ProdNameError = new System.Windows.Forms.ErrorProvider(this.components);
            this.ProdIDError = new System.Windows.Forms.ErrorProvider(this.components);
            this.ProdSellPriceError = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProdNameError)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProdIDError)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProdSellPriceError)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(355, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Add Products";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Product Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 175);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Product ID: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 204);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Product Description:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(30, 142);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Current Stock Amount:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(30, 240);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Cost Price:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(30, 271);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Selling Price: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(30, 305);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Supplier Name:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(30, 342);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Supplier ID:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(30, 380);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Supplier Address: ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(334, 422);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(129, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "Add Product Image below";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(166, 438);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(541, 219);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // FarmerAddImgbtn
            // 
            this.FarmerAddImgbtn.BackColor = System.Drawing.Color.White;
            this.FarmerAddImgbtn.Location = new System.Drawing.Point(378, 664);
            this.FarmerAddImgbtn.Name = "FarmerAddImgbtn";
            this.FarmerAddImgbtn.Size = new System.Drawing.Size(75, 23);
            this.FarmerAddImgbtn.TabIndex = 12;
            this.FarmerAddImgbtn.Text = "Upload ";
            this.FarmerAddImgbtn.UseVisualStyleBackColor = false;
            // 
            // FarmerAddProdbtn
            // 
            this.FarmerAddProdbtn.BackColor = System.Drawing.Color.White;
            this.FarmerAddProdbtn.Location = new System.Drawing.Point(702, 712);
            this.FarmerAddProdbtn.Name = "FarmerAddProdbtn";
            this.FarmerAddProdbtn.Size = new System.Drawing.Size(75, 23);
            this.FarmerAddProdbtn.TabIndex = 13;
            this.FarmerAddProdbtn.Text = "Add Product";
            this.FarmerAddProdbtn.UseVisualStyleBackColor = false;
            this.FarmerAddProdbtn.Click += new System.EventHandler(this.FarmerAddProdbtn_Click);
            // 
            // FarmerProdNameTb
            // 
            this.FarmerProdNameTb.Location = new System.Drawing.Point(166, 114);
            this.FarmerProdNameTb.Multiline = true;
            this.FarmerProdNameTb.Name = "FarmerProdNameTb";
            this.FarmerProdNameTb.Size = new System.Drawing.Size(297, 20);
            this.FarmerProdNameTb.TabIndex = 14;
            // 
            // FarmerProdQtyTb
            // 
            this.FarmerProdQtyTb.Location = new System.Drawing.Point(166, 142);
            this.FarmerProdQtyTb.Multiline = true;
            this.FarmerProdQtyTb.Name = "FarmerProdQtyTb";
            this.FarmerProdQtyTb.Size = new System.Drawing.Size(297, 20);
            this.FarmerProdQtyTb.TabIndex = 15;
            // 
            // FarmerProdIdTb
            // 
            this.FarmerProdIdTb.Location = new System.Drawing.Point(166, 168);
            this.FarmerProdIdTb.Multiline = true;
            this.FarmerProdIdTb.Name = "FarmerProdIdTb";
            this.FarmerProdIdTb.Size = new System.Drawing.Size(297, 20);
            this.FarmerProdIdTb.TabIndex = 16;
            // 
            // FarmerProdDescTb
            // 
            this.FarmerProdDescTb.Location = new System.Drawing.Point(166, 197);
            this.FarmerProdDescTb.Multiline = true;
            this.FarmerProdDescTb.Name = "FarmerProdDescTb";
            this.FarmerProdDescTb.Size = new System.Drawing.Size(297, 20);
            this.FarmerProdDescTb.TabIndex = 17;
            // 
            // FarmerProdCPTb
            // 
            this.FarmerProdCPTb.Location = new System.Drawing.Point(166, 232);
            this.FarmerProdCPTb.Multiline = true;
            this.FarmerProdCPTb.Name = "FarmerProdCPTb";
            this.FarmerProdCPTb.Size = new System.Drawing.Size(297, 20);
            this.FarmerProdCPTb.TabIndex = 18;
            this.FarmerProdCPTb.Text = "R";
            // 
            // FarmerProdSPTb
            // 
            this.FarmerProdSPTb.Location = new System.Drawing.Point(166, 264);
            this.FarmerProdSPTb.Name = "FarmerProdSPTb";
            this.FarmerProdSPTb.Size = new System.Drawing.Size(297, 20);
            this.FarmerProdSPTb.TabIndex = 19;
            this.FarmerProdSPTb.Text = "R";
            // 
            // FarmerProdSuppNameTb
            // 
            this.FarmerProdSuppNameTb.Location = new System.Drawing.Point(166, 298);
            this.FarmerProdSuppNameTb.Multiline = true;
            this.FarmerProdSuppNameTb.Name = "FarmerProdSuppNameTb";
            this.FarmerProdSuppNameTb.Size = new System.Drawing.Size(297, 20);
            this.FarmerProdSuppNameTb.TabIndex = 20;
            // 
            // FarmerProdSuppIDTb
            // 
            this.FarmerProdSuppIDTb.Location = new System.Drawing.Point(166, 335);
            this.FarmerProdSuppIDTb.Multiline = true;
            this.FarmerProdSuppIDTb.Name = "FarmerProdSuppIDTb";
            this.FarmerProdSuppIDTb.Size = new System.Drawing.Size(297, 20);
            this.FarmerProdSuppIDTb.TabIndex = 21;
            // 
            // FarmerProdSuppAddTb
            // 
            this.FarmerProdSuppAddTb.Location = new System.Drawing.Point(166, 373);
            this.FarmerProdSuppAddTb.Multiline = true;
            this.FarmerProdSuppAddTb.Name = "FarmerProdSuppAddTb";
            this.FarmerProdSuppAddTb.Size = new System.Drawing.Size(297, 20);
            this.FarmerProdSuppAddTb.TabIndex = 22;
            // 
            // ProdNameError
            // 
            this.ProdNameError.ContainerControl = this;
            // 
            // ProdIDError
            // 
            this.ProdIDError.ContainerControl = this;
            // 
            // ProdSellPriceError
            // 
            this.ProdSellPriceError.ContainerControl = this;
            // 
            // FarmerAddProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 749);
            this.Controls.Add(this.FarmerProdSuppAddTb);
            this.Controls.Add(this.FarmerProdSuppIDTb);
            this.Controls.Add(this.FarmerProdSuppNameTb);
            this.Controls.Add(this.FarmerProdSPTb);
            this.Controls.Add(this.FarmerProdCPTb);
            this.Controls.Add(this.FarmerProdDescTb);
            this.Controls.Add(this.FarmerProdIdTb);
            this.Controls.Add(this.FarmerProdQtyTb);
            this.Controls.Add(this.FarmerProdNameTb);
            this.Controls.Add(this.FarmerAddProdbtn);
            this.Controls.Add(this.FarmerAddImgbtn);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FarmerAddProduct";
            this.Text = "FarmerAddProduct";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProdNameError)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProdIDError)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProdSellPriceError)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button FarmerAddImgbtn;
        private System.Windows.Forms.Button FarmerAddProdbtn;
        private System.Windows.Forms.TextBox FarmerProdNameTb;
        private System.Windows.Forms.TextBox FarmerProdQtyTb;
        private System.Windows.Forms.TextBox FarmerProdIdTb;
        private System.Windows.Forms.TextBox FarmerProdDescTb;
        private System.Windows.Forms.TextBox FarmerProdCPTb;
        private System.Windows.Forms.TextBox FarmerProdSPTb;
        private System.Windows.Forms.TextBox FarmerProdSuppNameTb;
        private System.Windows.Forms.TextBox FarmerProdSuppIDTb;
        private System.Windows.Forms.TextBox FarmerProdSuppAddTb;
        private System.Windows.Forms.ErrorProvider ProdNameError;
        private System.Windows.Forms.ErrorProvider ProdIDError;
        private System.Windows.Forms.ErrorProvider ProdSellPriceError;
    }
}