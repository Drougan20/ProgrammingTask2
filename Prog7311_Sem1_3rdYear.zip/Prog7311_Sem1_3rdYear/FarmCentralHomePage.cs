﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Prog7311_Sem1_3rdYear
{
    public partial class FarmCentralHomePage : Form
    {
        SqlConnection prod = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\JALAAL\\source\\repos\\Prog7311_Sem1_3rdYear\\bin\\Debug\\MohammmadDb.mdf;Integrated Security=True");
        SqlCommand clay = new SqlCommand();
        SqlCommand mortar = new SqlCommand();
        public FarmCentralHomePage()
        {
            InitializeComponent();
        }

        private void SignOutbtn_Click(object sender, EventArgs e)
        {
            this.Close();
            OpeningPage op = new OpeningPage();
            op.Show();
        }

        private void FCHomePagelbl_Click(object sender, EventArgs e)
        {

        }

        private void claypic_Click(object sender, EventArgs e)
        {
            //string getclay;

            //getclay = "Select * From FarmerProdTable";

        }
    }
}
