﻿
namespace Prog7311_Sem1_3rdYear
{
    partial class LoginPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.FCUNLoginPagelbl = new System.Windows.Forms.Label();
            this.FCPWLoginPagelbl = new System.Windows.Forms.Label();
            this.FCLoginPageBtn = new System.Windows.Forms.Button();
            this.FCUNLoginPageTb = new System.Windows.Forms.TextBox();
            this.FCPWLoginPageTb = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Edwardian Script ITC", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(280, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "Farm Central Login Page";
            // 
            // FCUNLoginPagelbl
            // 
            this.FCUNLoginPagelbl.AutoSize = true;
            this.FCUNLoginPagelbl.Location = new System.Drawing.Point(265, 146);
            this.FCUNLoginPagelbl.Name = "FCUNLoginPagelbl";
            this.FCUNLoginPagelbl.Size = new System.Drawing.Size(58, 13);
            this.FCUNLoginPagelbl.TabIndex = 1;
            this.FCUNLoginPagelbl.Text = "Username:";
            // 
            // FCPWLoginPagelbl
            // 
            this.FCPWLoginPagelbl.AutoSize = true;
            this.FCPWLoginPagelbl.Location = new System.Drawing.Point(268, 190);
            this.FCPWLoginPagelbl.Name = "FCPWLoginPagelbl";
            this.FCPWLoginPagelbl.Size = new System.Drawing.Size(56, 13);
            this.FCPWLoginPagelbl.TabIndex = 2;
            this.FCPWLoginPagelbl.Text = "Password:";
            // 
            // FCLoginPageBtn
            // 
            this.FCLoginPageBtn.BackColor = System.Drawing.Color.White;
            this.FCLoginPageBtn.Location = new System.Drawing.Point(366, 266);
            this.FCLoginPageBtn.Name = "FCLoginPageBtn";
            this.FCLoginPageBtn.Size = new System.Drawing.Size(75, 23);
            this.FCLoginPageBtn.TabIndex = 3;
            this.FCLoginPageBtn.Text = "Confirm";
            this.FCLoginPageBtn.UseVisualStyleBackColor = false;
            this.FCLoginPageBtn.Click += new System.EventHandler(this.FCLoginPageBtn_Click);
            // 
            // FCUNLoginPageTb
            // 
            this.FCUNLoginPageTb.Location = new System.Drawing.Point(377, 138);
            this.FCUNLoginPageTb.Name = "FCUNLoginPageTb";
            this.FCUNLoginPageTb.Size = new System.Drawing.Size(224, 20);
            this.FCUNLoginPageTb.TabIndex = 4;
            // 
            // FCPWLoginPageTb
            // 
            this.FCPWLoginPageTb.Location = new System.Drawing.Point(377, 190);
            this.FCPWLoginPageTb.Name = "FCPWLoginPageTb";
            this.FCPWLoginPageTb.Size = new System.Drawing.Size(224, 20);
            this.FCPWLoginPageTb.TabIndex = 5;
            // 
            // LoginPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.FCPWLoginPageTb);
            this.Controls.Add(this.FCUNLoginPageTb);
            this.Controls.Add(this.FCLoginPageBtn);
            this.Controls.Add(this.FCPWLoginPagelbl);
            this.Controls.Add(this.FCUNLoginPagelbl);
            this.Controls.Add(this.label1);
            this.Name = "LoginPage";
            this.Text = "LoginPage";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label FCUNLoginPagelbl;
        private System.Windows.Forms.Label FCPWLoginPagelbl;
        private System.Windows.Forms.Button FCLoginPageBtn;
        private System.Windows.Forms.TextBox FCUNLoginPageTb;
        private System.Windows.Forms.TextBox FCPWLoginPageTb;
    }
}